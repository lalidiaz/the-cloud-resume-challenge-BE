import json
import boto3
from decimal import Decimal

client = boto3.client('dynamodb')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloud_resume_count_table')


COUNTER_ID = 'visitors'

def lambda_handler(event, context):
    print('Event:', event)
    
    body = {}
    statusCode = 200

    headers = {
        "Content-Type": "application/json",
    }

    try:
        route = event['routeKey']
        
        if route == "GET /counter": 
            # Get the counter
            response = table.get_item(
                Key={'id': COUNTER_ID}
            )
            
            if 'Item' in response:
                body = {'counter': response['Item']['counter']}
            else:
                # Create the counter if it doesn't exist yet
                table.put_item(
                    Item={
                        'id': COUNTER_ID,
                        'counter': 1
                    }
                )
                body = {'counter': 1}

        elif route == "PUT /counter":
            # Update the counter value - add 1
            response = table.update_item(
                Key={'id': COUNTER_ID},
                UpdateExpression='ADD #counter :incr',
                ExpressionAttributeNames={
                    '#counter': 'counter'
                },
                ExpressionAttributeValues={
                    ':incr': 1
                },
                ReturnValues='UPDATED_NEW'
            )
            
            if 'Attributes' in response:
                new_count = response['Attributes']['counter']
                body = {'counter': new_count}
            else:
                table.put_item(
                    Item={
                        'id': COUNTER_ID,
                        'counter': 1
                    }
                )
                body = {'counter': 1}

        else:
            statusCode = 404
            body = {'message': f'Unsupported route: {route}'}

    except Exception as e:
        print('Error:', str(e))
        statusCode = 500
        body = {
            'message': 'Internal server error',
            'error': str(e)
        }

    return {
        'statusCode': statusCode,
        'headers': headers,
        'body': json.dumps(body, default=str)  # default=str handles Decimal serialization
    }